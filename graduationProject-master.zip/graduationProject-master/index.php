<?php 
header('Location: hospital/index.php');
?>